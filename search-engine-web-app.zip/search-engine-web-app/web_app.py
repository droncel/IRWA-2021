import nltk
from flask import Flask, render_template, session
from flask import request
from datetime import datetime, timedelta
import requests
import json
from collections import Counter

from app.analytics.analytics_data import AnalyticsData, Click, UserSession
from app.search_engine.search_engine import SearchEngine
from app.core import utils

# pip install httpagentparser
import httpagentparser

app = Flask(__name__)
app.secret_key = 'OIJf4ff8g983'

searchEngine = SearchEngine()
analytics_data = AnalyticsData()

# Load tweets 
corpus = utils.load_documents_corpus()
num_d = len(corpus)

# Load the index (or create it, if needed)
index, tf, df, idf = utils.load_index_tfidf(corpus, num_d)
#index, tf, df, idf = create_index_tfidf(corpus, num_d)

# Load other values (necessary for our custom ranking algorithm)
fav_mean, rtw_mean = utils.load_fav_mean_rtw_mean(corpus, df)
#fav_mean, rtw_mean = tweets_popularity(corpus, df)

default_colors = ['#3366CC','#DC3912','#FF9900','#109618','#990099','#3B3EAC','#0099C6','#DD4477','#66AA00','#B82E2E','#316395','#994499','#22AA99','#AAAA11','#6633CC','#E67300','#8B0707','#329262','#5574A6','#3B3EAC']

@app.route('/')
def search_form():
    
    # Create session if needed
    if not 'id' in session:
        ## Retrieve user data
        # User device
        user_agent = httpagentparser.detect(request.headers.get('User-Agent'))
        attributes = {'platform' : 'Unknown', 'os': 'Unknown', 'dist': 'Unknown', 'browser': 'Unknown'}
        for attribute in attributes.keys():
            if attribute in user_agent.keys():
                attributes[attribute] = user_agent[attribute]['name']

        # ip
        ip = request.remote_addr

        # date
        dt = datetime.now()

        ## Add session to analytics
        s = UserSession(attributes['platform'], attributes['os'], attributes['dist'], attributes['browser'], ip, dt)
        
        analytics_data.sessions.append(s)
        print("n. sessions justo despues de crearlo", len(analytics_data.sessions))

        ## session
        session['id'] = s.id

    return render_template('index.html', page_title="Welcome")


@app.route('/search', methods=['POST'])
def search_form_post():
    search_query = request.form['search-query'].lower()

    i = session['id']
    print("n. sessions:", len(AnalyticsData.sessions))
    AnalyticsData.sessions[i].queries.append(search_query)
    session['query'] = search_query
    session['query_date'] = datetime.now()

    results = searchEngine.search(search_query, corpus, index, idf, tf, fav_mean, rtw_mean)

    if len(results) == 0:
        return render_template('no_results.html', results_list=results, page_title="No results found",  query=search_query)
    else: 
        found_count = len(results)    
        return render_template('results.html', results_list=results, page_title="Results", found_counter=found_count, query=search_query)


@app.route('/doc_details', methods=['GET'])
def doc_details():
    # Get id of the clicked tweet
    clicked_doc_id = int(request.args["id"])
    # Get ranking position of the clicked tweet
    ranking_position = int(request.args["position"])
    # Get the related query
    query = request.args["query"]

    analytics_data.fact_clicks.append(Click(clicked_doc_id, ranking_position, query, datetime.now()))

    print("click in id={} - fact_clicks len: {}".format(clicked_doc_id, len(analytics_data.fact_clicks)))
    
    doc = corpus[clicked_doc_id]
    return render_template('doc_details.html', page_title="Tweet details", doc = doc)

@app.route('/stats', methods=['GET'])
def stats():
    """
    Show simple statistics example. ### Replace with dashboard ###
    :return:
    """

    ## Data for the graph of the number of clicks per position
    click_position = [int(click.position) for click in AnalyticsData.fact_clicks]

    occurrences = Counter(click_position)
    if len(click_position) > 0:
        positions = [i for i in range(1, max(click_position)+1)]
        clicks = list()
        for position in positions:
            if position in occurrences:
                clicks.append(occurrences[position])
            else:
                clicks.append(0)
    else:
        positions = list()
        clicks = list()

    # Transform labels into string
    for i in range(len(positions)):
        positions[i] = str(positions[i])

    ## Data for the graph of the number of terms per query
    queries_len = list()
    for session in analytics_data.sessions:
        for query in session.queries:
            queries_len.append(len(query.split()))

    occurrences = Counter(queries_len)
    if len(queries_len) > 0:
        num_terms = [i for i in range(1, max(queries_len)+1)]
        ctr_num_terms = list()
        for num in num_terms:
            if num in occurrences:
                ctr_num_terms.append(occurrences[num])
            else:
                ctr_num_terms.append(0)
    else:
        num_terms = list()
        ctr_num_terms = list()

    # Transform labels into string
    for i in range(len(num_terms)):
        num_terms[i] = str(num_terms[i])

    ## Data for the browser distribution chart
    browser_list = list()
    for session in analytics_data.sessions:
            browser_list.append(session.browser)

    occurrences = Counter(browser_list)

    browser_names = list()
    ctr_browser = list()
    for b in sorted(occurrences.keys()):
        browser_names.append(b)
        ctr_browser.append(occurrences[b])

    browser_colors = default_colors[:len(browser_names)]

    ## Data for the OS distribution
    os_list = list()
    for session in analytics_data.sessions:
            os_list.append(session.os)

    occurrences = Counter(os_list)

    os_names = list()
    ctr_os = list()
    for op_sys in sorted(occurrences.keys()):
        os_names.append(op_sys)
        ctr_os.append(occurrences[op_sys])

    os_colors = default_colors[:len(os_names)]

    ## Data for the top queries
    queries_list = list()
    for session in analytics_data.sessions:
        queries_list += session.queries

    occurrences = Counter(queries_list)

    occurrences = sorted(occurrences.items(), key=lambda item: item[1])[:5]

    top_queries = list()
    top_queries_ctr = list()
    for item in sorted(occurrences):
        top_queries.append(item[0])
        top_queries_ctr.append(item[1])

    ## Data for the top tweets
    tweets_list = list()
    for click in analytics_data.fact_clicks:
        tweets_list.append(click.doc_id)

    occurrences = Counter(tweets_list)

    occurrences = sorted(occurrences.items(), key=lambda item: item[1])[:5]

    top_tweets = list()
    top_tweets_ctr = list()
    for item in sorted(occurrences):
        top_tweets.append(item[0])
        top_tweets_ctr.append(item[1])


    return render_template('stats.html', 
                            positions=positions, clicks=clicks,
                            num_terms=num_terms, ctr_num_terms=ctr_num_terms,
                            browser_names=browser_names, ctr_browser=ctr_browser, browser_colors=browser_colors,
                            os_names=os_names, ctr_os=ctr_os, os_colors=os_colors,
                            top_queries=top_queries, top_queries_ctr=top_queries_ctr,
                            top_tweets=top_tweets, top_tweets_ctr=top_tweets_ctr)

@app.route('/sentiment')
def sentiment_form():
    return render_template('sentiment.html')


@app.route('/sentiment', methods=['POST'])
def sentiment_form_post():
    text = request.form['text']
    nltk.download('vader_lexicon')
    from nltk.sentiment.vader import SentimentIntensityAnalyzer
    sid = SentimentIntensityAnalyzer()
    score = ((sid.polarity_scores(str(text)))['compound'])
    return render_template('sentiment.html', score=score)


if __name__ == "__main__":
    app.run(port="8088", host="0.0.0.0", threaded=False, debug=True)
