import datetime
from random import random
import os.path
import time
import string
from array import array
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
import json
import nltk
import demoji
import re
nltk.download('stopwords');
from deep_translator import GoogleTranslator
import pickle
import app.search_engine.algorithms as alg
from faker import Faker

fake = Faker()


# fake.date_between(start_date='today', end_date='+30d')
# fake.date_time_between(start_date='-30d', end_date='now')
#
# # Or if you need a more specific date boundaries, provide the start
# # and end dates explicitly.
# start_date = datetime.date(year=2015, month=1, day=1)
# fake.date_between(start_date=start_date, end_date='+30y')

def get_random_date():
    """Generate a random datetime between `start` and `end`"""
    return fake.date_time_between(start_date='-30d', end_date='now')


def get_random_date_in(start, end):
    """Generate a random datetime between `start` and `end`"""
    return start + datetime.timedelta(
        # Get a random amount of seconds between `start` and `end`
        seconds=random.randint(0, int((end - start).total_seconds())), )


class Document:
    def __init__(self, id_, title, full_text, text, date, user, url, retweets, favorites):
        self.id = id_
        self.title = title
        self.full_text = full_text
        self.text = text
        self.date = date
        self.user = user
        self.url = url
        self.retweets = retweets
        self.favorites = favorites


def italics_to_plaintext(text):
    #difference between an italic lowecase character and its corresponding plaintext lowercase character
    diff_lower = ord('𝘢') - ord('a')
    #difference between an italic uppercase character and its corresponding plaintext uppercase character
    diff_upper = ord('𝘈') - ord('A')
    
    plaintext = ""
    for c in text:
        # if the character is italic lowercase, get the corresponding plaintext lowercase character
        if ord(c) >= ord('𝘢') and ord(c) <= ord('𝘻'):
            plaintext += chr(ord(c) - diff_lower)
        # else if the character is italic uppercase, get the corresponding plaintext uppercase character
        elif ord(c) >= ord('𝘈') and  ord(c) <= ord('𝘡'):
            plaintext += chr(ord(c) - diff_upper)
        else:
            plaintext += c
    
    return plaintext


def bold_to_plaintext(text):
    #difference between a bold lowecase character and its corresponding plaintext lowercase character
    diff_lower = ord('𝐚') - ord('a')
    #difference between a bold uppercase character and its corresponding plaintext uppercase character
    diff_upper = ord('𝐀') - ord('A')
    
    plaintext = ""
    for c in text:
        # if the character is bold lowercase, get the corresponding plaintext lowercase character
        if ord(c) >= ord('𝐚') and ord(c) <= ord('𝐳'):
            plaintext += chr(ord(c) - diff_lower)
        # else if the character is bold uppercase, get the corresponding plaintext uppercase character
        elif ord(c) >= ord('𝐀') and  ord(c) <= ord('𝐙'):
            plaintext += chr(ord(c) - diff_upper)
        else:
            plaintext += c
    
    return plaintext


def getTerms(text, stemming, stops):
    # Text to lowercase
    text = text.lower()
    # Text delete italic letter type if needed
    text = italics_to_plaintext(text)
    # Text delete bold letter type if needed
    text = bold_to_plaintext(text)
    # Delete all urls
    text = re.sub(r'http\S+', ' ', text)
    # Delete all non-alphanumerical characters (it includes emojis) except '#' and '@'
    text = re.sub(r'[^A-Za-z0-9#@]+', ' ', text)
    # Text tokenization
    words = text.split()
    # Remove rt and username
    if len(words) > 0 and words[0] == 'rt':
        words = words[2:]
    # Remove stopwords
    words = [word for word in words if word not in stops]
    # Get the stem of each word
    words = [stemming.stem(word) for word in words]
    
    return words


def load_documents_corpus():
    """
    Load documents corpus from dataset_tweets_WHO.txt file
    :return:
    """

    docs_path = 'app/core/dataset_tweets_WHO.txt'

    # Read the JSON file in a unique string
    with open(docs_path) as fp:
        corpus = fp.readlines()[0]

    # Load the JSON file as a dictionary
    corpus = json.loads(corpus)

    stemming = PorterStemmer()
    # Delete also "amp" (&) and "rt"
    stops = set(stopwords.words("english")).union(set({'amp', 'rt'}))

    # Dictionary where we'll save all the processed tweets
    docs = []
    id_ = 0
    for tweet in corpus:

        #In case that the tweet is not in english, we traduce it
        lang = corpus[tweet]['lang']
        if lang != 'en':
            text_tweet = GoogleTranslator(target='en').translate(corpus[tweet]['full_text'])
        else:
            text_tweet = corpus[tweet]['full_text']
        
        # Get the text tokenized and cleaned 
        text_tweet_processed = getTerms(text_tweet, stemming, stops)

        if text_tweet_processed != []: #In case that the text is not null                       
            # Save creation data
            date = corpus[tweet]['created_at']

            # Save the number of retweets of this tweet
            retweets = corpus[tweet]['retweet_count']

            # Save the number of 'favorites' of this tweet
            favorites = corpus[tweet]['favorite_count']

            if 'retweeted_status' in corpus[tweet]:
                # Save the original tweet's user
                user = corpus[tweet]['retweeted_status']['user']['name']
                # Save the original tweet's url
                try:
                    url = corpus[tweet]['retweeted_status']['entities']['media'][0]['url']
                except: 
                    url = ''
            else:
                user = corpus[tweet]['user']['name']
                try:
                    url = corpus[tweet]['entities']['media'][0]['url']
                except: 
                    url = ''

            docs.append(Document(id_, ' '.join(text_tweet.split()[:6]), text_tweet, text_tweet_processed, date, user, url, retweets, favorites))
            id_ += 1

    return docs

def load_index_tfidf(corpus, num_d):
    try:
        index = pickle.load(open('app/data/index.p', 'rb'))
        tf = pickle.load(open('app/data/tf.p', 'rb'))
        df = pickle.load(open('app/data/df.p', 'rb'))
        idf = pickle.load(open('app/data/idf.p', 'rb'))
    except:
        index, tf, df, idf = alg.create_index_tfidf(corpus, num_d)

        pickle.dump(index, open('app/data/index.p', 'wb'))
        pickle.dump(tf, open('app/data/tf.p', 'wb'))
        pickle.dump(df, open('app/data/df.p', 'wb'))
        pickle.dump(idf, open('app/data/idf.p', 'wb'))

    return index, tf, df, idf

def load_fav_mean_rtw_mean(corpus, df):
    try:
        fav_mean = pickle.load(open('app/data/fav_mean.p', 'rb'))
        rtw_mean = pickle.load(open('app/data/rtw_mean.p', 'rb'))
    except:
        fav_mean, rtw_mean = alg.tweets_popularity(corpus, df)

        pickle.dump(fav_mean, open('app/data/fav_mean.p', 'wb'))
        pickle.dump(rtw_mean, open('app/data/rtw_mean.p', 'wb'))

    return fav_mean, rtw_mean