class AnalyticsData:
    fact_clicks = []
    sessions = []

class Click:
    def __init__(self, doc_id, position, query, dt):
        self.doc_id = doc_id
        self.position = position
        self.query = query
        self.dt = dt

class UserSession:

    next_id = 0

    def __init__(self, platform, os, dist, browser, ip, dt):
        self.id = UserSession.next_id
        self.platform = platform
        self.os = os
        self.dist = dist
        self.browser = browser
        self.ip = ip
        self.dt = dt

        self.queries = list()

        UserSession.next_id += 1