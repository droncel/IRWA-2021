import random
#from app.core.utils import get_random_date
from app.search_engine.algorithms import search_sbdm


def build_data(corpus, results_idxs, results_scores):
    """
    :return: a list of docs sorted by ranking
    """

    res = []
    for i in range(len(results_idxs)):
        doc = corpus[results_idxs[i]]
        res.append(DocumentInfo(doc.id, doc.title, doc.full_text, doc.date, doc.user, 
                                doc.url, doc.retweets, doc.favorites, i+1))

    return res


class SearchEngine:
    """educational search engine"""
    i = 12345

    ###

    def search(self, search_query, corpus, index, idf, tf, fav_mean, rtw_mean, fav_rate = 1, rtw_rate = 0.5, date_rate = 0.5):
        print("Search query:", search_query)
        results = []
        
        results_idxs, results_scores = search_sbdm(search_query, corpus, index, idf, tf, fav_mean, rtw_mean, fav_rate, rtw_rate, date_rate)
        results = build_data(corpus, results_idxs, results_scores)

        return results


class DocumentInfo:
    def __init__(self, id_, title, full_text, date, user, url, retweets, favorites, ranking):
        self.id = id_
        self.title = title
        self.full_text = full_text
        self.date = date
        self.user = user
        self.url = url
        self.retweets = retweets
        self.favorites = favorites
        self.ranking = ranking
