from collections import defaultdict
from nltk.stem import PorterStemmer
import math
import numpy as np
import collections
from numpy import linalg as la
from nltk.corpus import stopwords
from array import array
import dateutil.parser
import datetime
from app.core.utils import getTerms

def create_index_tfidf(corpus, num_d):
    """
    Implement the inverted index and compute tf, df and idf
    
    Input:
    * lines: collection of Wikipedia articles
    * num_d: total number of documents
    
    Returns:
    * index: the inverted index (implemented through a python dictionary) containing terms as keys and the corresponding 
    * list of document these keys appears in (and the positions) as values
    * tf: normalized term frequency for each term in each document
    * df: number of documents each term appear in
    * idf: inverse document frequency of each term
    """
        
    index = defaultdict(list)
    tf = defaultdict(list) #term frequencies of terms in documents (documents in the same order as in the main index)
    df = defaultdict(int) #document frequencies of terms in the corpus
    idf = defaultdict(float)
    
    for doc in corpus:   
        terms = doc.text

        termdictTweet = {}

        for position, term in enumerate(terms): # Tweet's terms
            try:
                # If the term is already in the dict append the position to the corrisponding list
                termdictTweet[term][1].append(position) 
            except:
                # Add the new term as dict key and initialize the array of positions and add the position
                termdictTweet[term] = [doc.id, array('I',[position])] 
        
        # Normalize term frequencies
        norm = 0
        for term, posting in termdictTweet.items(): 
            norm += len(posting[1])**2
        norm = math.sqrt(norm)


        # Calculate the tf and df weights
        for term, posting in termdictTweet.items():     
            # Append the tf
            tf[term].append(np.round(len(posting[1])/norm,4))
            # Increment the document frequency of current term
            df[term] += len(posting)
        
        # Merge the current tweet index with the main index
        for termtweet, postingtweet in termdictTweet.items():
            index[termtweet].append(postingtweet)
            
        # Compute idf
        for term in df:
            idf[term] = np.round(np.log(float(num_d/df[term])),4)
            
    return index, tf, df, idf

def tweets_popularity(corpus, df):
    
    fav_mean = defaultdict(float)
    rtw_mean = defaultdict(float)
    
    for doc in corpus:
        for word in doc.text:
            if word not in fav_mean: 
                fav_mean[word] = doc.favorites
                rtw_mean[word] = doc.retweets
            else:
                fav_mean[word] += doc.favorites
                rtw_mean[word] += doc.retweets
                
    for word in fav_mean:
        fav_mean[word] = fav_mean[word] / df[word]
        rtw_mean[word] = rtw_mean[word] / df[word]
    
    return fav_mean, rtw_mean

def compute_diff_date(date):
    return (datetime.datetime.now().replace(tzinfo=None) - date.replace(tzinfo=None)).days

def rankTweets_sbdm(terms, tweets, corpus, index, idf, tf, fav_mean, rtw_mean, fav_rate, rtw_rate, date_rate):
    
    #Initialize the dictionaries with the tweets' vectors
    tweetVectors_terms = defaultdict(lambda: [0]*len(terms))
    tweetVectors_fav = defaultdict(lambda: [0]*len(terms))
    tweetVectors_rtw = defaultdict(lambda: [0]*len(terms))
    tweetVectors = defaultdict(lambda: [0]*len(terms))
    
    #Initialize the query vector
    queryVector_terms, queryVector_fav, queryVector_rtw = [0]*len(terms), [0]*len(terms), [0]*len(terms)

    # Compute the norm for the query TF
    query_terms_count = collections.Counter(terms) # get the frequency of each term in the query 
    query_norm = la.norm(list(query_terms_count.values()))
    
    #Get TF-IDF vectors
    for termIndex, term in enumerate(terms): #termIndex is the index of the term in the query
        if term not in index:
            continue
                    
        ## Compute tf*idf normalized
        queryVector_terms[termIndex] = (query_terms_count[term] / query_norm) * idf[term]

        # Generate tweetVectors for matching docs
        for tweetIndex, (tweet, postings) in enumerate(index[term]):
            if tweet in tweets:
                tweetVectors_terms[tweet][termIndex] = tf[term][tweetIndex]
    
    #Get population vectors
    for termIndex, term in enumerate(terms): 
        if term not in index:
            continue
                    
        queryVector_fav[termIndex] = fav_mean[term]
        queryVector_rtw[termIndex] = rtw_mean[term]

        for tweetIndex, (tweet, postings) in enumerate(index[term]):
            if tweet in tweets:
                tweetVectors_fav[tweet][termIndex] = fav_mean[term]
                tweetVectors_rtw[tweet][termIndex] = rtw_mean[term]
    
    
    #We normalize the population vectors
    queryVector_fav = queryVector_fav / la.norm(queryVector_fav)
    queryVector_rtw = queryVector_rtw / la.norm(queryVector_rtw)
    
    for tweet in tweetVectors_fav:
        tweetVectors_fav[tweet] = tweetVectors_fav[tweet] / la.norm(tweetVectors_fav[tweet])
        tweetVectors_rtw[tweet] = tweetVectors_rtw[tweet] / la.norm(tweetVectors_rtw[tweet])    
    
    #Final tweets and query vectors
    for tweet, curTweetVec in tweetVectors_terms.items():
        tweetVectors[tweet] = curTweetVec + rtw_rate*tweetVectors_rtw[tweet] + fav_rate*tweetVectors_fav[tweet]
        tweet_date = dateutil.parser.parse(corpus[tweet].date)
        date_diff = compute_diff_date(tweet_date)
        tweetVectors[tweet] = np.append(tweetVectors[tweet], 1/(date_diff*date_rate))
    
    queryVector = queryVector_terms + rtw_rate*queryVector_rtw + fav_rate*queryVector_fav
    queryVector = np.append(queryVector, 1/date_rate)
    
    #We compute cosine similarity
    tweetScores = [[np.dot(curTweetVec, queryVector), tweet] for tweet, curTweetVec in tweetVectors.items()]
    tweetScores.sort(reverse=True)
    scores = [x[0] for x in tweetScores]
    resultTweets = [x[1] for x in tweetScores]
    if len(resultTweets) == 0:
        print("No results found, try again")
        query = input()
        #tweets = search_tf_idf(query, index) 
        tweets = search_sbdm(query, corpus, index, idf, tf, fav_mean, rtw_mean, fav_rate, rtw_rate, date_rate)
    return resultTweets, scores

def search_sbdm(query, corpus, index, idf, tf, fav_mean, rtw_mean, fav_rate = 1, rtw_rate = 0.5, date_rate = 0.5):
    stemming = PorterStemmer()
    stops = set(stopwords.words("english")).union(set({'amp', 'rt'}))
    
    query = getTerms(query, stemming, stops)
    tweets = set()

    for i, term in enumerate(query):
        try:
            # store in termDocs the ids of the docs that contain "term"                        
            termDocs = [posting[0] for posting in index[term]]
            
            # if this is the first word of the query, save all the tweets with this word
            if i == 0:
                tweets = tweets.union(termDocs)
            # for the next words, only keey those that contain that word and all the past words of the query
            else:
                tweets = tweets.intersection(termDocs)
        except:
            #term is not in index
            pass
    
    tweets = list(tweets)
    ranked_tweets = list()
    scores = list()
    
    if len(tweets) != 0: 
        ranked_tweets, scores = rankTweets_sbdm(query, tweets, corpus, index, idf, tf, fav_mean, rtw_mean, fav_rate, rtw_rate, date_rate)   

    return ranked_tweets, scores